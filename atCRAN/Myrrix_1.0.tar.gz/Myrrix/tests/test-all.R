library(testthat)
test_package("Myrrix")
